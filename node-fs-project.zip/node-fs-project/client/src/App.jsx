import { useEffect, useState } from 'react';
import * as api from './api.js';
import './App.css';

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  return `${(bytes / 1024).toFixed(1)} KB`;
}

export default function App() {
  const [files, setFiles] = useState([]);
  const [apiOk, setApiOk] = useState(null);
  const [selected, setSelected] = useState(null); // filename
  const [content, setContent] = useState('');
  const [appendText, setAppendText] = useState('');
  const [renaming, setRenaming] = useState(false);
  const [newName, setNewName] = useState('');
  const [newFile, setNewFile] = useState({ name: '', content: '' });
  const [status, setStatus] = useState(null); // { type: 'ok'|'error', text }

  async function refreshList() {
    try {
      const data = await api.listFiles();
      setFiles(data);
      setApiOk(true);
    } catch (err) {
      setApiOk(false);
      setStatus({ type: 'error', text: err.message });
    }
  }

  useEffect(() => {
    refreshList();
  }, []);

  async function openFile(name) {
    try {
      const data = await api.readFile(name);
      setSelected(name);
      setContent(data.content);
      setRenaming(false);
      setStatus(null);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  function say(type, text) {
    setStatus({ type, text });
  }

  async function handleCreate(e) {
    e.preventDefault();
    if (!newFile.name.trim()) return;
    try {
      await api.createFile(newFile.name.trim(), newFile.content);
      say('ok', `Created ${newFile.name} — fs.writeFile()`);
      const created = newFile.name.trim();
      setNewFile({ name: '', content: '' });
      await refreshList();
      openFile(created);
    } catch (err) {
      say('error', err.message);
    }
  }

  async function handleSave() {
    try {
      await api.updateFile(selected, content);
      say('ok', `Saved ${selected} — fs.writeFile()`);
      refreshList();
    } catch (err) {
      say('error', err.message);
    }
  }

  async function handleAppend() {
    if (!appendText) return;
    try {
      await api.appendFile(selected, appendText);
      const data = await api.readFile(selected);
      setContent(data.content);
      setAppendText('');
      say('ok', `Appended to ${selected} — fs.appendFile()`);
      refreshList();
    } catch (err) {
      say('error', err.message);
    }
  }

  async function handleRename() {
    if (!newName.trim()) return;
    try {
      await api.renameFile(selected, newName.trim());
      say('ok', `Renamed to ${newName} — fs.rename()`);
      const renamed = newName.trim();
      setNewName('');
      setRenaming(false);
      await refreshList();
      openFile(renamed);
    } catch (err) {
      say('error', err.message);
    }
  }

  async function handleDelete(name) {
    try {
      await api.deleteFile(name);
      say('ok', `Deleted ${name} — fs.unlink()`);
      if (selected === name) {
        setSelected(null);
        setContent('');
      }
      refreshList();
    } catch (err) {
      say('error', err.message);
    }
  }

  return (
    <div className="cabinet">
      <header className="cabinet-header">
        <div>
          <h1 className="cabinet-title">
            <span className="prompt">fs://</span>cabinet
          </h1>
          <div className="cabinet-subtitle">Node.js fs module, demonstrated live</div>
        </div>
        <span className={`api-status ${apiOk === null ? '' : apiOk ? 'ok' : 'error'}`}>
          {apiOk === null ? 'checking API…' : apiOk ? 'API connected' : 'API unreachable'}
        </span>
      </header>

      <div className="cabinet-grid">
        {/* -------- sidebar: directory listing -------- */}
        <aside className="sidebar">
          <div className="sidebar-label">fs.readdir() · data/</div>
          {files.length === 0 ? (
            <div className="empty-dir">No files yet. Create one below.</div>
          ) : (
            <ul className="file-list">
              {files.map((f) => (
                <li
                  key={f.name}
                  className={`file-item${selected === f.name ? ' active' : ''}`}
                  onClick={() => openFile(f.name)}
                >
                  <span className="fname">{f.name}</span>
                  <span className="fsize">{formatBytes(f.size)}</span>
                </li>
              ))}
            </ul>
          )}

          <form className="new-file-form" onSubmit={handleCreate}>
            <input
              placeholder="filename.txt"
              value={newFile.name}
              onChange={(e) => setNewFile((f) => ({ ...f, name: e.target.value }))}
              required
            />
            <input
              placeholder="initial content (optional)"
              value={newFile.content}
              onChange={(e) => setNewFile((f) => ({ ...f, content: e.target.value }))}
            />
            <button type="submit" className="fs-action">
              <span className="fs-action-label">+ New file</span>
              <span className="fs-call-badge">fs.writeFile()</span>
            </button>
          </form>
        </aside>

        {/* -------- main panel: selected file buffer -------- */}
        <main className="buffer-panel">
          {!selected ? (
            <div className="buffer-empty">Select a file on the left, or create a new one.</div>
          ) : (
            <>
              <div className="buffer-header">
                <span className="buffer-filename">{selected}</span>
                {!renaming ? (
                  <button
                    className="fs-action"
                    onClick={() => {
                      setRenaming(true);
                      setNewName(selected);
                    }}
                  >
                    <span className="fs-action-label">Rename</span>
                    <span className="fs-call-badge">fs.rename()</span>
                  </button>
                ) : (
                  <div className="rename-row">
                    <input value={newName} onChange={(e) => setNewName(e.target.value)} />
                    <button className="fs-action" onClick={handleRename}>
                      <span className="fs-action-label">Confirm</span>
                    </button>
                    <button className="fs-action" onClick={() => setRenaming(false)}>
                      <span className="fs-action-label">Cancel</span>
                    </button>
                  </div>
                )}
              </div>

              <div className="buffer-body">
                <textarea
                  className="buffer-textarea"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                />

                <div className="action-bar">
                  <button className="fs-action" onClick={handleSave}>
                    <span className="fs-action-label">Save (overwrite)</span>
                    <span className="fs-call-badge">fs.writeFile()</span>
                  </button>
                  <button className="fs-action danger" onClick={() => handleDelete(selected)}>
                    <span className="fs-action-label">Delete</span>
                    <span className="fs-call-badge">fs.unlink()</span>
                  </button>
                </div>

                <div className="append-box">
                  <textarea
                    placeholder="Text to append to the end of the file…"
                    value={appendText}
                    onChange={(e) => setAppendText(e.target.value)}
                  />
                  <div className="action-bar">
                    <button className="fs-action" onClick={handleAppend} disabled={!appendText}>
                      <span className="fs-action-label">Append</span>
                      <span className="fs-call-badge">fs.appendFile()</span>
                    </button>
                  </div>
                </div>
              </div>
            </>
          )}

          {status && (
            <div className={`status-line ${status.type}`}>
              {status.type === 'ok' ? '✓ ' : '✗ '}
              {status.text}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
