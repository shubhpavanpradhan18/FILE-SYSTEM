const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000/api';

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.message || `Request failed (${res.status})`);
  }
  return data;
}

export const listFiles = () => request('/files');
export const readFile = (name) => request(`/files/${encodeURIComponent(name)}`);
export const createFile = (filename, content) =>
  request('/files', { method: 'POST', body: JSON.stringify({ filename, content }) });
export const updateFile = (name, content) =>
  request(`/files/${encodeURIComponent(name)}`, { method: 'PUT', body: JSON.stringify({ content }) });
export const appendFile = (name, content) =>
  request(`/files/${encodeURIComponent(name)}/append`, {
    method: 'PATCH',
    body: JSON.stringify({ content })
  });
export const renameFile = (name, newName) =>
  request(`/files/${encodeURIComponent(name)}/rename`, {
    method: 'PUT',
    body: JSON.stringify({ newName })
  });
export const deleteFile = (name) => request(`/files/${encodeURIComponent(name)}`, { method: 'DELETE' });
