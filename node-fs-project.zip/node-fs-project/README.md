# Node fs Module Demo

Demonstrates Node.js's built-in `fs` module — `readdir`, `stat`, `readFile`, `writeFile`, `appendFile`, `rename`, `unlink` — through a small REST API and a matching React frontend ("fs://cabinet").

```
node-fs-project/
├── server/   Express API wrapping fs.promises calls (fsUtils.js) + a data/ folder as the "disk"
└── client/   React (Vite) frontend — browse, create, edit, append, rename, delete files
```

Every action in the UI is labeled with the exact `fs.*` call it triggers, so it doubles as a live reference for the module while you use it.

## Run both

Terminal 1 — API:
```bash
cd server
npm install
npm run dev          # http://localhost:4000
```

Terminal 2 — frontend:
```bash
cd client
npm install
cp .env.example .env  # points at http://localhost:4000/api by default
npm run dev            # http://localhost:5173
```

No database — files are created for real inside `server/data/`, so you can also just watch that folder in a file explorer while using the app.

## fs calls used, and where

| Operation | fs call | File |
|---|---|---|
| List files | `fs.readdir` | `server/fsUtils.js` → `listFiles` |
| File metadata (size, dates) | `fs.stat` | `server/fsUtils.js` → `listFiles` |
| Read a file | `fs.readFile` | `server/fsUtils.js` → `readFile` |
| Create a file (fails if it exists) | `fs.writeFile` (flag `wx`) | `server/fsUtils.js` → `createFile` |
| Overwrite a file | `fs.writeFile` | `server/fsUtils.js` → `updateFile` |
| Append to a file | `fs.appendFile` | `server/fsUtils.js` → `appendToFile` |
| Rename a file | `fs.rename` | `server/fsUtils.js` → `renameFile` |
| Delete a file | `fs.unlink` | `server/fsUtils.js` → `deleteFile` |

See `server/fsUtils.js` for the actual calls — each function wraps exactly one.
