const express = require('express');
const cors = require('cors');
const fsUtils = require('./fsUtils');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.json({ message: 'Node fs module demo API is running' });
});

// GET /api/files — list files with size/created/modified (fs.readdir + fs.stat)
app.get('/api/files', async (req, res) => {
  try {
    const files = await fsUtils.listFiles();
    res.json(files);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/files/:filename — read one file's content (fs.readFile)
app.get('/api/files/:filename', async (req, res) => {
  try {
    const content = await fsUtils.readFile(req.params.filename);
    res.json({ name: req.params.filename, content });
  } catch (err) {
    if (err.code === 'ENOENT') return res.status(404).json({ message: 'File not found' });
    res.status(500).json({ message: err.message });
  }
});

// POST /api/files — create a new file (fs.writeFile with 'wx' flag)
app.post('/api/files', async (req, res) => {
  try {
    const { filename, content } = req.body;
    if (!filename) return res.status(400).json({ message: 'filename is required' });
    await fsUtils.createFile(filename, content);
    res.status(201).json({ message: `${filename} created` });
  } catch (err) {
    if (err.code === 'EEXIST') return res.status(409).json({ message: 'A file with that name already exists' });
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/files/:filename — overwrite a file's content (fs.writeFile)
app.put('/api/files/:filename', async (req, res) => {
  try {
    await fsUtils.updateFile(req.params.filename, req.body.content);
    res.json({ message: `${req.params.filename} updated` });
  } catch (err) {
    if (err.code === 'ENOENT') return res.status(404).json({ message: 'File not found' });
    res.status(500).json({ message: err.message });
  }
});

// PATCH /api/files/:filename/append — append text to a file (fs.appendFile)
app.patch('/api/files/:filename/append', async (req, res) => {
  try {
    await fsUtils.appendToFile(req.params.filename, req.body.content);
    res.json({ message: `Appended to ${req.params.filename}` });
  } catch (err) {
    if (err.code === 'ENOENT') return res.status(404).json({ message: 'File not found' });
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/files/:filename/rename — rename a file (fs.rename)
app.put('/api/files/:filename/rename', async (req, res) => {
  try {
    const { newName } = req.body;
    if (!newName) return res.status(400).json({ message: 'newName is required' });
    await fsUtils.renameFile(req.params.filename, newName);
    res.json({ message: `Renamed to ${newName}` });
  } catch (err) {
    if (err.code === 'ENOENT') return res.status(404).json({ message: 'File not found' });
    if (err.code === 'EEXIST') return res.status(409).json({ message: 'A file with that name already exists' });
    res.status(500).json({ message: err.message });
  }
});

// DELETE /api/files/:filename — delete a file (fs.unlink)
app.delete('/api/files/:filename', async (req, res) => {
  try {
    await fsUtils.deleteFile(req.params.filename);
    res.json({ message: `${req.params.filename} deleted` });
  } catch (err) {
    if (err.code === 'ENOENT') return res.status(404).json({ message: 'File not found' });
    res.status(500).json({ message: err.message });
  }
});

app.use((req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`fs-demo server running on http://localhost:${PORT}`);
});
