// This file exists to make the Node.js `fs` module calls easy to point to —
// each function below wraps exactly one fs operation.

const fs = require('fs/promises');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');

// keep filenames inside the data folder — no ../.. escaping it
function safePath(filename) {
  const resolved = path.join(DATA_DIR, filename);
  if (!resolved.startsWith(DATA_DIR)) {
    throw new Error('Invalid filename');
  }
  return resolved;
}

// fs.readdir — list every file in the data folder
async function listFiles() {
  const names = await fs.readdir(DATA_DIR);
  const visible = names.filter((n) => n !== '.gitkeep');

  // fs.stat — get size/created/modified time for each file
  const withStats = await Promise.all(
    visible.map(async (name) => {
      const stats = await fs.stat(safePath(name));
      return {
        name,
        size: stats.size,
        createdAt: stats.birthtime,
        modifiedAt: stats.mtime
      };
    })
  );

  return withStats.sort((a, b) => b.modifiedAt - a.modifiedAt);
}

// fs.readFile — read one file's content as text
async function readFile(filename) {
  return fs.readFile(safePath(filename), 'utf-8');
}

// fs.writeFile with flag 'wx' — create a new file, fails if it already exists
async function createFile(filename, content) {
  await fs.writeFile(safePath(filename), content ?? '', { flag: 'wx' });
}

// fs.writeFile — overwrite a file's entire content
async function updateFile(filename, content) {
  await fs.writeFile(safePath(filename), content ?? '');
}

// fs.appendFile — add text to the end of a file without touching what's already there
async function appendToFile(filename, content) {
  await fs.appendFile(safePath(filename), content ?? '');
}

// fs.rename — rename/move a file
async function renameFile(oldName, newName) {
  await fs.rename(safePath(oldName), safePath(newName));
}

// fs.unlink — delete a file
async function deleteFile(filename) {
  await fs.unlink(safePath(filename));
}

module.exports = {
  listFiles,
  readFile,
  createFile,
  updateFile,
  appendToFile,
  renameFile,
  deleteFile
};
