# fs-demo server

A small Express API that wraps Node's `fs` module. See `fsUtils.js` — every function there wraps exactly one `fs` call, on purpose, so it's easy to point to in a walkthrough.

## Endpoints

| Method | Route | fs call | Description |
|---|---|---|---|
| GET | `/api/files` | `readdir` + `stat` | List files with size/created/modified |
| GET | `/api/files/:filename` | `readFile` | Read a file's content |
| POST | `/api/files` | `writeFile` (`wx`) | Create a new file — 409 if it already exists |
| PUT | `/api/files/:filename` | `writeFile` | Overwrite a file's content |
| PATCH | `/api/files/:filename/append` | `appendFile` | Append text to a file |
| PUT | `/api/files/:filename/rename` | `rename` | Rename a file |
| DELETE | `/api/files/:filename` | `unlink` | Delete a file |

## Setup

```bash
npm install
npm run dev      # http://localhost:4000
```

Files are written for real into `data/` — open that folder in a file explorer alongside the running app to watch it change live.
